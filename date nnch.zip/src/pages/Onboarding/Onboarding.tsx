import React from 'react';
import OnboardingForm from './OnboardingForm';

function Onboarding() {
  return <OnboardingForm />;
}

export default Onboarding;